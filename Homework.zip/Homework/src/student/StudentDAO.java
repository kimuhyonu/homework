package student;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

public class StudentDAO {
	
	Connection conn = null;
	String url="jdbc:oracle:thin:@localhost:1521:xe";
	String user="scott";
	String pw="tiger";
	
	private Connection Connect() {
	
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url,user,pw);
			
		} catch (Exception e) {
			System.out.println("커넥션 오류");
			e.printStackTrace();
		}
		return conn;		
	}
	private void disConnect() {
		
		try {
			if(conn !=null) {
				conn.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			conn=null;
			
		}
	}
	
	public boolean insertDB(StudentDTO student) {
		Connect();
		PreparedStatement pstm = null;
		String sql ="INSERT INTO stu_report(STU_ID,STU_NAME,STU_GRADE,STU_SUBJECT1,STU_SUBJECT2,STU_SUBJECT3,PRO_NAME1,PRO_NAME2,PRO_NAME3,SUM,AVG,GRADE,MEMO,SCORE1,SCORE2,SCORE3) VALUES(members_seq.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		
		try {
			conn.setAutoCommit(false);
			pstm=conn.prepareStatement(sql);
			pstm.setString(1, student.getStu_name());
			pstm.setInt(2, student.getStu_grade());
			pstm.setString(3, student.getStu_subject1());
			pstm.setString(4, student.getStu_subject2());
			pstm.setString(5, student.getStu_subject3());
			pstm.setString(6, student.getPro_name1());
			pstm.setString(7, student.getPro_name2());
			pstm.setString(8, student.getPro_name3());
			pstm.setInt(9, student.getSum());
			pstm.setInt(10, student.getAvg());
			pstm.setString(11, student.getGrade());
			pstm.setString(12, student.getMemo());
			pstm.setInt(13, student.getScore1());
			pstm.setInt(14, student.getScore2());
			pstm.setInt(15, student.getScore3());
			pstm.executeUpdate();
			pstm.close();
			conn.commit();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("입력오류");
			
			return false;
		}finally {
			disConnect();
			
		}
			
		return true;
	}
	
	public boolean updateDB(StudentDTO student) {
		Connect();
		PreparedStatement pstm = null;
		String sql="update stu_report set SCORE1=?, SCORE2=?, SCORE3=?,SUM=?,AVG=?,GRADE=?, MEMO=? where STU_ID=?";
		
		
		try {
			conn.setAutoCommit(false);
			pstm=conn.prepareStatement(sql);
			pstm.setInt(1, student.getScore1());
			pstm.setInt(2, student.getScore2());
			pstm.setInt(3, student.getScore3());
			pstm.setInt(4, student.getSum());
			pstm.setInt(5, student.getAvg());
			pstm.setString(6, student.getGrade());
			pstm.setString(7, student.getMemo());
			pstm.setInt(8, student.getStu_id());
			pstm.executeUpdate();
			pstm.close();
			conn.commit();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			disConnect();
		}	
		return true;
	}
	public boolean deleteDB(int stu_id) {
		Connect();
		PreparedStatement pstm = null;
		String sql = "delete from stu_report where STU_ID=?";
		
		try {
			conn.setAutoCommit(false);
			pstm=conn.prepareStatement(sql);
			pstm.setInt(1, stu_id);
			pstm.executeUpdate();
			pstm.close();
			conn.commit();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("삭제오류");
			return false;
		}finally {
			disConnect();
		}
		return true;
	}
	public StudentDTO getDB(int stu_id) {
		Connect();
		StudentDTO add = new StudentDTO();
		PreparedStatement pstm =null;
		String sql= "SELECT*FROM stu_report where STU_ID=?";
		
		try {
			conn.setAutoCommit(false);
			pstm = conn.prepareStatement(sql);
			pstm.setInt(1, stu_id);
			ResultSet rs =pstm.executeQuery();
			if(rs.next()) {
			
				add.setStu_id(rs.getInt("STU_ID"));
				add.setStu_name(rs.getString("STU_NAME"));
				add.setStu_grade(rs.getInt("STU_GRADE"));
				add.setStu_subject1(rs.getString("STU_SUBJECT1"));
				add.setStu_subject2(rs.getString("STU_SUBJECT2"));
				add.setStu_subject3(rs.getString("STU_SUBJECT3"));
				add.setPro_name1(rs.getString("PRO_NAME1"));
				add.setPro_name2(rs.getString("PRO_NAME2"));
				add.setPro_name3(rs.getString("PRO_NAME3"));
				add.setSum(rs.getInt("SUM"));
				add.setAvg(rs.getInt("AVG"));
				add.setGrade(rs.getString("GRADE"));
				add.setMemo(rs.getString("MEMO"));
				add.setScore1(rs.getInt("SCORE1"));
				add.setScore2(rs.getInt("SCORE2"));
				add.setScore3(rs.getInt("SCORE3"));
			}
			rs.close();
			pstm.close();
			conn.commit();
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		return add;
	}
	
	//��ü �˻�
	
	public Vector<StudentDTO> getDBList(){
		Connect();
		Vector<StudentDTO> datas = new Vector<StudentDTO>();
		
		Statement stmt =null;
		String sql = "select*from stu_report order by STU_ID ASC";
		
		
		try {
			conn.setAutoCommit(false);
			stmt=conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
			StudentDTO add = new StudentDTO();
			add.setStu_id(rs.getInt("STU_ID"));
			add.setStu_name(rs.getString("STU_NAME"));
			add.setStu_grade(rs.getInt("STU_GRADE"));
			add.setStu_subject1(rs.getString("STU_SUBJECT1"));
			add.setStu_subject2(rs.getString("STU_SUBJECT2"));
			add.setStu_subject3(rs.getString("STU_SUBJECT3"));
			add.setPro_name1(rs.getString("PRO_NAME1"));
			add.setPro_name2(rs.getString("PRO_NAME2"));
			add.setPro_name3(rs.getString("PRO_NAME3"));
			add.setSum(rs.getInt("SUM"));
			add.setAvg(rs.getInt("AVG"));
			add.setGrade(rs.getString("GRADE"));
			add.setMemo(rs.getString("MEMO"));
			add.setScore1(rs.getInt("SCORE1"));
			add.setScore2(rs.getInt("SCORE2"));
			add.setScore3(rs.getInt("SCORE3"));
			
			datas.add(add);
			}
			rs.close();
			stmt.close();
			conn.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			disConnect();
		}
		return datas;
	}
}


