package student;


public class StudentDTO {

			int stu_id;
			String stu_name;
			int stu_grade;
			String stu_subject1;
			String stu_subject2;
			String stu_subject3;
			String pro_name1;
			String pro_name2;
			String pro_name3;
			int sum; 
			int avg;
			String grade;
			String memo;
			int score1;
			int score2;
			int score3;
			
			
			public int getStu_id() {
				return stu_id;
			}
			public void setStu_id(int stu_id) {
				this.stu_id = stu_id;
			}
			public String getStu_name() {
				return stu_name;
			}
			public void setStu_name(String stu_name) {
				this.stu_name = stu_name;
			}
			public int getStu_grade() {
				return stu_grade;
			}
			public void setStu_grade(int stu_grade) {
				this.stu_grade = stu_grade;
			}
			public String getStu_subject1() {
				return stu_subject1;
			}
			public void setStu_subject1(String stu_subject1) {
				this.stu_subject1 = stu_subject1;
			}
			public String getStu_subject2() {
				return stu_subject2;
			}
			public void setStu_subject2(String stu_subject2) {
				this.stu_subject2 = stu_subject2;
			}
			public String getStu_subject3() {
				return stu_subject3;
			}
			public void setStu_subject3(String stu_subject3) {
				this.stu_subject3 = stu_subject3;
			}
			public String getPro_name1() {
				return pro_name1;
			}
			public void setPro_name1(String pro_name1) {
				this.pro_name1 = pro_name1;
			}
			public String getPro_name2() {
				return pro_name2;
			}
			public void setPro_name2(String pro_name2) {
				this.pro_name2 = pro_name2;
			}
			public String getPro_name3() {
				return pro_name3;
			}
			public void setPro_name3(String pro_name3) {
				this.pro_name3 = pro_name3;
			}
			public int getSum() {
				
				return sum=score1+score2+score3;
			}
			public void setSum(int sum) {
				this.sum = sum;
			}
			public int getAvg() {
				return avg=sum/3;
			}
			public void setAvg(int avg) {
				this.avg = avg;
			}
			public String getGrade() {
				if(avg>90) {
					 grade="A";
				}else if(89>avg&&avg>80) {
					 grade="B";
				}else if(79>avg&&avg>70) {
					 grade="C";
				}else if(69>avg&&avg>60) {
					 grade="D";
				}else if(59>avg&&avg>50) {
					 grade="F";
				}
				return grade;
			}
			public void setGrade(String grade) {
				this.grade = grade;
			}
			public String getMemo() {
				return memo;
			}
			public void setMemo(String memo) {
				this.memo = memo;
			}
			public int getScore1() {
				return score1;
			}
			public void setScore1(int score1) {
				this.score1 = score1;
			}
			public int getScore2() {
				return score2;
			}
			public void setScore2(int score2) {
				this.score2 = score2;
			}
			public int getScore3() {
				return score3;
			}
			public void setScore3(int score3) {
				this.score3 = score3;
			}
			
	
	
}
